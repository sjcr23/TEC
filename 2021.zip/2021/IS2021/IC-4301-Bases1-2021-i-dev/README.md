IS2021 -> BASES-1 -> Mi-TEC-Digital -> Tarea#4
==========================================

[![Java CI with Maven](https://github.com/sjcr23/mi-tec-digital/actions/workflows/maven.yml/badge.svg)](https://github.com/sjcr23/mi-tec-digital/actions/workflows/maven.yml)

**Descripción:**  
  · Aplicación Demo para gestionar *Estudiantes,* utilizando   
     por atributos el ```carnét, nombre, apellido y edad.``` 

**Profesores:**  
  · Martín Flores  
  · Allan Cascante

**Estudiante:**  
  · Josué Castro Ramírez  
  · Carné: ```2020065036```
