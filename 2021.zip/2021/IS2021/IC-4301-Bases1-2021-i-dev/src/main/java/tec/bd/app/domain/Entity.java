package tec.bd.app.domain;

public interface Entity {

}
