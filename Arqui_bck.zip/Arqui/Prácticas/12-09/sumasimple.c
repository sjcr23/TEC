#include <stdio.h>
int main()
{
    //Este programa realiza la suma simple de dos números enteros
    printf("Sumando dos enteros\n");
    int suma = 2 + 3;
    printf("%i",suma);
    return 0;
}

