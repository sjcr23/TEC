Hola! Mi nombre completo es Josué David Castro Ramírez, pero me puedes
decir chino ^-^
Me encanta tocar música y aprender nuevos idiomas; en general me gusta
aprender cosas nuevas y tener nuevos desafíos :)

May the force be with you!
