### -2020IIS-POO-Proyecto1-Mosqueteros
Grupo de trabajo del Primer Proyecto Programado del curso Programación Orientada a Objetos



## Videos

### Alberto Zumbado Abarca

<https://youtu.be/piyRJNrQ4cw>

### Josué Castro Ramírez

<https://youtu.be/4xYdUjYsNY4>
