# IIProyectoPOO-barquitos-
Segundo proyecto Programado del curso Programación Orientada a Objetos



### Alberto Zumbado

https://youtu.be/kqQ0FiMyLIQ

Luis Andrés Rojas Murillo:
https://youtu.be/3OCuESp9QjM 

