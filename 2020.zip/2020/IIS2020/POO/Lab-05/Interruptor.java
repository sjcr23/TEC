public interface Interruptor {
	public abstract void encender();
	public abstract void apagar();
}
