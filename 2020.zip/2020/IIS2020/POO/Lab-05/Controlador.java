import java.util.ArrayList;

public class Controlador extends ArrayList<Aparato>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
