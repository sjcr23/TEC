#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define vi vector<int>
#define MAXP 100005
#define oo 1L<<60

int tablaFeliz[MAXP][3];
ll memo[MAXP][3];

int N;

ll felicidad(int dia, int act){
	if(dia==N) return 0;
	if(memo[dia][act]) return memo[dia][act];
	ll resp = tablaFeliz[dia][act];
	return memo[dia][act] = resp+max(felicidad(dia+1, (act+1)%3),
	                                 felicidad(dia+1, (act+2)%3));
}

int main(){
	cin>>N;
	for(int i =0; i<N; i++)cin>>tablaFeliz[i][0]>>tablaFeliz[i][1]>>tablaFeliz[i][2];
	ll maximaFelicidad = 0;
	for(int i = 0; i<3; i++){
		maximaFelicidad = max(felicidad(0,i), maximaFelicidad);
	}
	cout<<maximaFelicidad<<"\n";
}
