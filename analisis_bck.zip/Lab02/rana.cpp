#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define vi vector<int>
#define MAXP 1000005
#define oo 1L<<60

int piedras[MAXP];
ll memo[MAXP];
int visitado[MAXP];

int N;

ll rana(int p){
	if(p>=N) return oo;
	if(p == N-1) return 0;
	if(visitado[p]) return memo[p];
	visitado[p] = 1;
	return memo[p] = min(rana(p+1)+abs(piedras[p]-piedras[p+1]),
		                rana(p+2)+abs(piedras[p]-piedras[p+2]));
}

int main(){
	cin>>N;
	for(int i =0; i<N; i++)cin>>piedras[i];
	cout<<rana(0)<<"\n";
}
