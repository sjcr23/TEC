#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define vi vector<int>
#define ITEMS 105
#define CAPACIDAD 1000000005
#define oo 1L<<60

int valor[ITEMS];
int peso[ITEMS];

ll memo[ITEMS][CAPACIDAD];

int it,cap;

ll mochila(int item, int k){
	if(k<0) return -oo;
	if(!k) return k;
	if(item >= it) return 0;
	if(memo[item][k]) return memo[item][k];
	return memo[item][k] = max(valor[item]+mochila(item+1, k-peso[item]), mochila(item+1,k));
}

int main(){
	cin>>it>>cap;
	for(int i =0; i<it; i++)cin>>peso[i]>>valor[i];
	
	cout<<mochila(0,cap)<<"\n";
}
