import Tries

arbol = Tries.Trie2()
T = int(input())
assert (1 <= T <= 200)
casos = []

for i in range(T):
	n = input().split()
	assert len(n) <= 49
	casos += n

casos.sort()
r = 0
for i in casos:
	r += arbol.insertar_y_contar(i)
print(r)
