import Tries

arbol = Tries.Trie1()
T = int(input())
assert (1 <= T <= 200)

for i in range(T):
	entrada = input().split()
	P = int(entrada[0])
	R = int(entrada[1])
	assert (1 <= P <= 30) and (1 <= R <= 1000)
	
	# Recopilación de datos de las carreras
	for carrera in range(P):
		cantidad = int(input())
		nombres = input().split()
		assert (len(nombres) == cantidad)
		for nombre in nombres:
			arbol.insertar(nombre, carrera)
	
	# Recopilación de datos de los CVs.
	for cvs in range(R):
		cantidad = int(input())
		profesiones = input().split()
		assert (len(profesiones) == cantidad)
		validos = []
		for descripcion in profesiones:
			caso = arbol.validar_descripcion(descripcion)
			if caso and caso not in validos:
				validos.append(caso)
		print(len(validos))
