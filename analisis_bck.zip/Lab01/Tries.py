# class Nodo1:
#	 self.letra : str  → El campo contiene un solo caracter de un string.
#    self.fin   : bool → El campo contiene un booleano que indica si es el fin de un string.
#	 self.hijos : list → El campo contiene una lista de posibles nodos, se reserva uno espacio por cada posible
#						  caracter del alfabeto minúsculo en inglés. (26 espacios)
#	 self.ids   : list → El campo contiene una lista con los posibles ids de la carrera a los que esté asociado el nodo.
class Nodo1:
	def __init__(self, chr: str, id: int):
		self.letra = chr
		self.fin = False
		self.hijos = [None] * 26
		self.ids = [id]

# class Trie1:
#	 self.raiz : Nodo1 → Este campo siempre contiene un Nodo1 con '!' como letra y 0 com id.

# Métodos:
#    agregar_id(id) :  → Este método recibe un int y lo agrega a la lista de ids del nodo.

#	 insertar(palabra, id):
#		→ Este método recorre el Trie por cada letra de 'palabra', si en los hijos del nodo no existe un nodo con esa
#		letra; crea un nuevo nodo con la letra y el 'id' correspondiente. Además, lo asigna a la lista de nodos, ese
#		espacio lo reserva utilizando la función ord() para obtener el índice correcto.

#    validar_descripcion(descripcion):
#		→ Este método recorre el Trie por cada letra de 'descripcion', si en los hijos del nodo no existe un nodo con
#		esa letra retorna falso. Si no, pregunta si la canditad de elementos en la 'lista de ids' del nodo > 1; de ser
#		el caso retorna False, si no retorna la cantidad.
class Trie1:

	def __init__(self):
		self.raiz = Nodo1('!', 0)
	
	def insertar(self, palabra, id):
		actual = self.raiz
		for letra in palabra:
			indice = ord(letra) - ord('a')
			if actual.hijos[indice] is None:
				actual.hijos[indice] = Nodo1(letra, id)
			actual = actual.hijos[indice]
			if id not in actual.ids:
				actual.ids.append(id)
		actual.fin = True
	
	def validar_descripcion(self, descripcion):
		actual = self.raiz
		for letra in descripcion:
			indice = ord(letra) - ord('a')
			if actual.hijos[indice] is None:
				return False
			actual = actual.hijos[indice]
		
		if len(actual.ids) > 1:
			return False
		return actual.ids[0]
	
# class Nodo2:
#	 self.letra : str  → El campo contiene un solo caracter de un string.
#    self.fin   : bool → El campo contiene un int que indica si es el fin de un string. [0 = Falso, 1 = Verdadero]
#	 self.hijos : list → El campo contiene una lista de posibles nodos, se reserva uno espacio por cada posible
#						 caracter entre 0 y 9. (10 espacios)
class Nodo2:
	def __init__(self, chr: str):
		self.letra = chr
		self.fin = 0
		self.hijos = [None] * 10

# class Trie2:
#	 self.raiz : Nodo2 → Este campo siempre contiene un Nodo1 con '!' letra.

# Métodos:
#	 insertar_y_contar(palabra):
#		→ Este método recorre el Trie por cada letra de 'palabra', si en los hijos del nodo no existe un nodo con esa
#		letra; crea un nuevo nodo con la letra. Además, lo asigna a la lista de nodos, ese espacio lo reserva utilizan-
#		do la función ord() para obtener el índice correcto. Si el nodo existe suma a 'contador' el campo de 'nodo.fin'
#       porque esto quiere decir que el nodo es prefijo de la palabra insertada. Después de recorrer la palabra, se de-
#       clara el fin = 1 y se retorna el contador.
#       → NOTA: Este método es efectivo siempre y cuando la lista de strings recibida esté ordenada.
class Trie2:
	def __init__(self):
		self.raiz = Nodo2('!')
	
	def insertar_y_contar(self, palabra):
		actual = self.raiz
		contador = 0
		for letra in palabra:
			indice = ord(letra) - ord('0')
			if actual.hijos[indice] is None:
				actual.hijos[indice] = Nodo2(letra)
			actual = actual.hijos[indice]
			contador += actual.fin
		actual.fin = 1
		return contador
	