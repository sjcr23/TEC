#include<bits/stdc++.h>

using namespace std;

//TEST indica si el b-simo bit de a está prendido
#define TEST(a,b) ((a) & (1<<(b)))

//SET prende el b-simo bit de a
#define SET(a,b) ((a) | (1<<(b)))

//FLIP voltear el estado del bsimo bit de a
#define FLIP(a,b) ((a) ^ (1<<(b)))

//CLEAR apaga el estado del bsimo bit de a
#define CLEAR(a,b) ((a) & ~(1<<(b)))


int memo[1<<12+5];

int countBits(int n){
	int cant = 0;
	while(n){
		cant+=n&1;
		n>>1;
	}
	return cant;
}

int minBolitas(int msk){
	if(memo[msk]) return memo[msk];
	int mini = 13;
	int hayJugadas = 0;
	//Jugadas hacia la izquierda
	for(int i = 0; i<10; i++){
		if(TEST(msk,i) && TEST(msk,i+1) && !TEST(msk,i+2)){
			int nvaMsk = CLEAR(msk,i);
			nvaMsk = CLEAR(nvaMsk,i+1);
			nvaMsk = SET(nvaMsk,i+2);
			mini = min(mini, minBolitas(nvaMsk));
			hayJugadas = 1;			
		}
	}
	//Jugadas hacia la derecha
	for(int i = 11; i>1; i--){
		if(TEST(msk,i) && TEST(msk,i-1) && !TEST(msk,i-2))
		{
			int nvaMsk = CLEAR(msk,i);
			nvaMsk = CLEAR(nvaMsk,i-1);
			nvaMsk = SET(nvaMsk,i-2);
			mini = min(minBolitas(nvaMsk));
			hayJugadas = 1;
		}
	}
	if(!hayJugadas) memo[msk] = countBits(msk);
	else memo[msk] = mini;
	return memo[msk];
}


string s = "cba";

void toBin(int n){
	for(int i = 30; i!=-1; i--)
		TEST(n,i)? cout<<1 : cout<<0;
	cout<<endl;
}





int main(){
	/*for(int i = 0; i<1<<3 ; i++){cout<<"  Conjunto:"<<i<<": ";
		for(int pos = 0; pos<3; pos++)
			if(TEST(i,pos)) cout<<s[pos];
		cout<<endl;
	}*/
	int casos;
	cin>>casos;
	while(casos--){
		string entrada;
		cin>>entrada;
		int msk = 0;
		for(int i = 0; entrada[i]; i++)
			if(entrada[i] == 'o') msk = SET(msk,i);
		cout<<minBolitas(msk)<<"\n";
	}
	
}
