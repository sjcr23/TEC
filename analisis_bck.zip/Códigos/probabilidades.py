from random import randint


ListaOcurrencias = []

def llenarOcurrencias():
	for i in range(1000):
		ListaOcurrencias.append(0)

def dado():
	return randint(1,6)

llenarOcurrencias()

for i in range(6000):
	cant = 1;
	while (dado() != 1):
		cant+=1
	ListaOcurrencias[(999+cant-abs(cant-999))//2]+=1

P = 1/6

# Distribución Geométrica

for i in range(1,30):
	print(str(i)+": "+str(ListaOcurrencias[i])+" PE:"+str((1-P)**(i-1)*P*6000) )

