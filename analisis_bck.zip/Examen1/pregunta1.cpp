#include <bits/stdc++.h>
using namespace std;

#define vi vector<int>
#define vs vector<string>
#define to_int(x) atoi(x.c_str())

int to_bin(string n){
    int r = 0;
    for (int i = n.size() - 1; i >= 0; i--){
        r += (1 << i) * (n[i] - '0');
    }
    return r;
}

int VEHICULOS;

vi resolver(vs feat)
{
    vi soluciones;
    for (int i = 0; i < feat.size(); i++){
        int matches = 0;
        for (int j = 0; j < feat.size(); j++){
            if (i != j)            {
                int num = to_int(feat[i]) ^ to_int(feat[j]);
                auto str = std::to_string(num);
                num = to_bin(str);
                if (num == (num & -num))
                    matches++;
            }
            else;
        }
        soluciones.push_back(matches);
    }
    return soluciones;
}

int main(){
    cin >> VEHICULOS;
    vs features(VEHICULOS);
    for (int i = 0; i < VEHICULOS; i++)
        cin >> features[i];
    vi sol = resolver(features);
    for (int i = 0; i < VEHICULOS; i++)
        cout << sol[i] << " ";
}