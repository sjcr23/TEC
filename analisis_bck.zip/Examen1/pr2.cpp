#include <bits/stdc++.h>
using namespace std;

#define vi vector<int>
#define vvi vector<vector<int>>
#define TIEMPO_APERTURA 600
#define oo 1L << 60

int A, T;
vi felicidad;
vi duracion;
vvi inicios;

long long int diversion();


int main()
{
    cin >> A >> T;
    for (int i = 0; i < A; i++){
        cin >> felicidad[i] >> duracion[i];
        int horarios;
        cin >> horarios;
        while (horarios--){
            int hora;
            cin >> hora;
            inicios[i].push_back(hora);
        }
    }
    cout << diversion() << "\n";
}