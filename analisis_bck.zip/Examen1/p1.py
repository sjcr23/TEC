
def to_int(n):
    r = 0
    for i in range(len(n)):
        r += (1<<i) * int(n[i])
    return r

def resolver(feat):
    m = []
    for n in feat:
        print(n)
        for r in feat:
            c = n ^r
            if n == r: pass
            elif c in m: pass
            else:
                print(bin(c))
                m.append(c)
            
    return m


VEHICULOS = int(input())
features = []

for i in range(VEHICULOS):
    feature = to_int(input()[::-1])
    features.append(feature)

print(features)
sol = resolver(features)
print(sol)
