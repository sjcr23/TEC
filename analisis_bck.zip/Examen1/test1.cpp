#include <bits/stdc++.h>
using namespace std;

long int m4(int a, int b){
    long int temporal;
    while (b != 0){

        cout << "temp:" << temporal;
        cout << "\na = " << a << " | ";
        cout << "b = " << b << " | ";
        cout << "a % b = " << a % b << "\n";
        temporal = b;
        b = a % b;
        a = temporal;
        cout << "\n";
    }
    return a;
}

int main(){
    long int cas = m4(93, 7);
    cout << cas << "\n";
}